package com.ttsc.inputmodule;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import android.os.Environment;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.HashMap;
import java.io.File;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private EditText editText;
    private TextToSpeech textToSpeech;
    private Spinner speechrate1,speechpitch1;
    String valuefromspinner1 = "1.0";
    String valuefromspinner2 = "1.0";
    float sr= (float) 1.0,sp= (float) 1.0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText = findViewById(R.id.editText);


        Spinner speechrate1 = (Spinner) findViewById(R.id.spinner1);
        String[] speechrate2 = getResources().getStringArray(R.array.speech_rates);
        ArrayAdapter adapter1 = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item, speechrate2);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        speechrate1.setAdapter(adapter1);
        speechrate1.setOnItemSelectedListener(this);

        Spinner speechpitch1 = (Spinner) findViewById(R.id.spinner2);
        String[] speechpitch2 = getResources().getStringArray(R.array.speech_rates);
        ArrayAdapter adapter2 = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item, speechpitch2);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        speechpitch1.setAdapter(adapter2);
        speechpitch1.setOnItemSelectedListener(this);

        textToSpeech = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener()  {
            @Override
            public void onInit(int i) {
                textToSpeech.setLanguage(Locale.US);
            }
        });
    }

    public void TextToSpeechButton(View view){
        textToSpeech.setSpeechRate(sr);
        textToSpeech.setPitch(sp);
        textToSpeech.speak(editText.getText().toString(), TextToSpeech.QUEUE_FLUSH, null,null);
    }
    public void stopbutton(View view){
        textToSpeech.stop();
    }




    public void synthesis(View view){
        if (this.editText.getText().toString().equals("")) {
            Toast.makeText(MainActivity.this, "No text to save", Toast.LENGTH_SHORT).show();
        } else  if (ContextCompat.checkSelfPermission(MainActivity.this, WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(MainActivity.this, new String[] { WRITE_EXTERNAL_STORAGE }, 1024);
            ActivityCompat.requestPermissions(MainActivity.this, new String[] { READ_EXTERNAL_STORAGE }, 1025);
        }
        else {
            Calendar date = Calendar.getInstance();
            String dir_name =  "tts";
            final String filepath = Environment.getExternalStorageDirectory() + "/" + dir_name + "/" + (date.get(2) + "_" + date.get(5) + "_" + date.get(1) + "__" + date.get(11) + "_" + date.get(12) + "_" + date.get(13)) + ".wav";
            File file = new File(Environment.getExternalStorageDirectory() + "/" + dir_name);
            if (!file.exists()) {
                file.mkdir();
            }
            HashMap<String, String> hm = new HashMap<>();
            hm.put(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, this.editText.getText().toString());
            this.textToSpeech.synthesizeToFile(this.editText.getText().toString(), hm, filepath);
            Toast.makeText(MainActivity.this, "Saved in" + filepath, Toast.LENGTH_SHORT).show();
        }
    }




    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if (parent.getId()==R.id.spinner1){
            valuefromspinner1 = parent.getItemAtPosition(position).toString();
            sr=Float.parseFloat(valuefromspinner1);
        }
        if (parent.getId()==R.id.spinner2){
            valuefromspinner2 = parent.getItemAtPosition(position).toString();
            sp=Float.parseFloat(valuefromspinner2);
        }
    }
    @Override
    public void onNothingSelected(AdapterView<?> parent) { }
}
